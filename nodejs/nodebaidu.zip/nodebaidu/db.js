module.exports = {
	/* 建立数据库连接池 */
	mysql:{
		host: 'localhost',
		port: 3306,
		user: 'root',
		password: '',
		database: 'baidunews'
	}
};