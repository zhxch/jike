<?php
/**
 * Created by PhpStorm.
 * User: xiaochunjie
 * Date: 16/11/30
 * Time: 09:42
 */
    header("Content-type:application/json; charset=utf-8");
    $con = mysqli_connect("localhost", "root", "", "baidunews", 3306);

?>